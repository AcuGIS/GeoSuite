![GeoHelm Quick Start](https://geohelm.org/img/geohelm-logo.png)

# Quick Start Scripts for GeoHelm

These scripts install Webmin and install the GeoHelm.

For use on clean installs only

AcuGIS, GeoHelm  &copy; 2020 Cited, Inc. All Rights Reserved
