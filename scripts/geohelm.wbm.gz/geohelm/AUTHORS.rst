Authors
-------

* David Ghedini
* Kaloyan Petrov
